import streamlit as st  
import streamlit.components.v1 as components
# EDA Packages
import pandas as pd
import numpy as np
import random


# Machine Learning Packages
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

import os
import time
from datetime import datetime


import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
nltk.download('stopwords')
import re
import sklearn
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

st.set_page_config(page_title='Spam detection',
                   page_icon=':spam:',
                   layout='wide')

st.markdown(
    """
    <style>
    .reportview-container {
        background-color: #D3D3D3;
    }
    </style>
    """,
    unsafe_allow_html=True
)

def main():
    activites = ["Fake link detection","Abusive language detection","Spam with repeated text detection"]
    choice = st.sidebar.selectbox("Select Activity",activites)

    if choice=="Fake link detection":
        html_temp1 = """
      <div style= "background-color:#778899;"><p style="color:white; font-size:60px; width:70%;">Fake link detection</p></div>
	"""
        components.html(html_temp1)
        text2 = st.text_area("Input link for detection",height=300)
        urls_data = pd.read_csv("urldata.csv")
        def makeTokens(f):
            tkns_BySlash = str(f.encode('utf-8')).split('/')	# make tokens after splitting by slash
            total_Tokens = []
            for i in tkns_BySlash:
                tokens = str(i).split('-')	# make tokens after splitting by dash
                tkns_ByDot = []
                for j in range(0,len(tokens)):
                    temp_Tokens = str(tokens[j]).split('.')	# make tokens after splitting by dot
                    tkns_ByDot = tkns_ByDot + temp_Tokens
                total_Tokens = total_Tokens + tokens + tkns_ByDot
            total_Tokens = list(set(total_Tokens))	#remove redundant tokens
            if 'com' in total_Tokens:
                total_Tokens.remove('com')	#removing .com since it occurs a lot of times and it should not be included in our features
            return total_Tokens
        if st.button("check"):
            
            y = urls_data["label"]
            url_list = urls_data["url"]
            vectorizer = TfidfVectorizer(tokenizer=makeTokens)
            X = vectorizer.fit_transform(url_list)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            logit = LogisticRegression(solver='lbfgs',class_weight='balanced', max_iter=10000)
            logit.fit(X_train, y_train)
            # st.success("Accuracy ",logit.score(X_test, y_test))
            X_predict = [
        
                "https://gritblast.top/bigbazaar/tb.php?_t=1623860843",
                "pakistanifacebookforever.com/getpassword.php/", 
                "www.radsport-voggel.de/wp-admin/includes/log.exe", 
                "ahrenhei.without-transfer.ru/nethost.exe ",
                "www.itidea.it/centroesteticosothys/img/_notes/gum.exe"]
            X_predict = vectorizer.transform(X_predict)
            New_predict = logit.predict(X_predict)
            
            st.success(New_predict)
            X_predict1 = vectorizer.transform(X_predict1)
            New_predict1 = logit.predict(X_predict1)
            st.success(New_predict1)


    elif choice == "Spam with repeated text detection":
        html_temp = """
      <div style= "background-color:#778899;"><p style="color:white; font-size:60px; width:70%;">Spam detection</p></div>
	"""
        components.html(html_temp)
        text1 = st.text_area("Input Text For detection",height=300)
        if st.button("check"):
            # res = dict(item.split("-") for item in text1.split(", "))
            res = {text1[i]: text1[i + 1] for i in range(0, len(text1), 2)}
            count=0
            tres=[]
            kres=[]
            list1=[]
            for x in res.keys():
                kres.append(x)
            for y in res.values():
                tres.append(y)
            st.success(tres)
            for x,y in res.items():
                
                if(x in kres):
                    count=count+1
                    time_1 = datetime.strptime(y,"%H:%M:%S")
                    list1.append(time_1)
                    if(count>5):
                        time_2=list1[count-1]
                        n=time_2 - time_1
                        if (n < 2) :
                            st.success("SPAM")
                        else:
                            st.success("NOT SPAM")
    
    
    elif choice=="Abusive language detection":
        html_temp2 = """
      <div style= "background-color:#778899;"><p style="color:white; font-size:60px; width:70%;">Abusive language detection</p></div>
	"""
        components.html(html_temp2)
        text2 = st.text_area("Input text for detection",height=300)
        sms = pd.read_csv('labeled_data.csv')
        sms.keys()
        df=sms.drop(['Unnamed: 0', 'count', 'hate_speech', 'offensive_language', 'neither'],axis=1)
        df.drop_duplicates(inplace=True)
        df.reset_index(drop=True, inplace=True)
        corpus = []
        ps = PorterStemmer()

        for i in range(0,df.shape[0]):
            message = re.sub(pattern='[^a-zA-Z]', repl=' ', string=df.tweet[i]) #Cleaning special character from the message
            message = message.lower() #Converting the entire message into lower case
            words = message.split() # Tokenizing the review by words
            words = [word for word in words if word not in set(stopwords.words('english'))] #Removing the stop words
            words = [ps.stem(word) for word in words] #Stemming the words
            message = ' '.join(words) #Joining the stemmed words
            corpus.append(message) #Building a corpus of messages
       
        cv = CountVectorizer(max_features=2500)
        X = cv.fit_transform(corpus).toarray()
        y = pd.get_dummies(df['target'])
        y = y.iloc[:, 1].values
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=0)
        best_accuracy = 0.0
        alpha_val = 0.0
        for i in np.arange(0.0,1.1,0.1):
            temp_classifier = MultinomialNB(alpha=i)
            temp_classifier.fit(X_train, y_train)
            temp_y_pred = temp_classifier.predict(X_test)
            score = accuracy_score(y_test, temp_y_pred)
            print("Accuracy score for alpha={} is: {}%".format(round(i,1), round(score*100,2)))
            if score>best_accuracy:
                best_accuracy = score
                alpha_val = i
        # st.success('--------------------------------------------')
        # st.warning('The best accuracy is {}% with alpha value as {}'.format(round(best_accuracy*100, 2), round(alpha_val,1)))
        classifier = MultinomialNB(alpha=0.1)
        classifier.fit(X_train, y_train)
        y_pred = classifier.predict(X_test)
       
        def predict_spam(sample_message):
            sample_message = re.sub(pattern='[^a-zA-Z]',repl=' ', string = sample_message)
            sample_message = sample_message.lower()
            sample_message_words = sample_message.split()
            sample_message_words = [word for word in sample_message_words if not word in set(stopwords.words('english'))]
            ps = PorterStemmer()
            final_message = [ps.stem(word) for word in sample_message_words]
            final_message = ' '.join(final_message)
            temp = cv.transform([final_message]).toarray()
            return classifier.predict(temp)
        result = ['Wait a minute, this is a abusive!','Ohhh, this is a normal message.']
        msg = " You Bitchh!! "

        if predict_spam(msg):
            st.warning(result[0])
        else:
            st.warning(result[1])
       


hide_st_style = """
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)        
        
       
    
if __name__ == '__main__':
    main()
